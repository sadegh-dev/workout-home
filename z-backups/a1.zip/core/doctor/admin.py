from django.contrib import admin
from .models import doctor


admin.site.register(doctor)