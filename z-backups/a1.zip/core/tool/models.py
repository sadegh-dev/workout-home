from django.db import models
from django.urls import reverse


class Tool(models.Model):
    name = models.CharField(max_length=200)
    store = models.CharField(max_length=200)
    price = models.CharField(max_length=200)
    slug = models.SlugField(max_length=50,unique=True)
    descriptions = models.TextField(max_length=3000)
    the_link = models.URLField(null=True, blank=True, max_length=5000)
    pic = models.ImageField(null=True, blank=True, upload_to='tools/')

    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name



