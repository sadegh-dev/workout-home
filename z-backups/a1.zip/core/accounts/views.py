from django.shortcuts import render


def dashboard(request):
    pass


def details(request):
    pass